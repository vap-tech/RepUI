export class CollectionController {}
